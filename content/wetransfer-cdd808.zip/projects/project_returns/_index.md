---
date: "2017-10-31T22:27:21-05:00"
draft: false
image: pic02.jpg
slug: blogs
title: Lifestyle
---

My blogs about technology and lifestyle.